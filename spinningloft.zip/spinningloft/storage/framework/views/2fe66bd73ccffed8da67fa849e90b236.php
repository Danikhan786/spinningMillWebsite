

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Properties</h1>
        <a 
        href="<?php echo e(route('properties.create')); ?>" 
        class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">Add Property</a>
    </div>
    <!-- Content Row -->
    <div class="row">
        <!-- DataTales Example -->
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Property Table</h6>
                </div>
                <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                    <div class="alert alert-success" role="alert"> <?php echo e($value); ?> </div>
                <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Property Id</th>
                                    <th>Property Image</th>
                                    <th>Name</th>
                                    <th>Location</th>
                                    <th>Bed</th>
                                    <th>Bath</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($property->id); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/' . $property->propertyImage)); ?>" width="100px">
                                        </td>
                                        <td><?php echo e($property->propertyName); ?></td>
                                        <td><?php echo e($property->location); ?></td>
                                        <td><?php echo e($property->bed); ?></td>
                                        <td><?php echo e($property->bath); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('properties.destroy', $property->id)); ?>" method="POST">  
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('properties.edit', $property->id)); ?>">
                                                    <i class="fa-solid fa-pen-to-square"></i> Edit
                                                </a>
                                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">There are no data.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\devoasis\spinningMillWebsite\spinningMillLofts\resources\views\properties\index.blade.php ENDPATH**/ ?>